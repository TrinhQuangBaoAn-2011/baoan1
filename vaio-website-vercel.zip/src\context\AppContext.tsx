import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { DayPlan, MockExam, Profile, QuizSession, RefStatus, Snapshot, Task } from '../lib/types';
import type { Ops } from '../lib/mutations';
import {
  addMock,
  defaultSnapshot,
  saveProfile,
  saveQuizSession,
  setRefProgress,
  setTaskDone,
  toggleFreeze,
  totalXp,
} from '../lib/mutations';
import { createStore, type Store } from '../lib/storage';
import { useAuth } from './AuthContext';
import { computeStreak, type StreakInfo } from '../lib/streak';
import { todayISO } from '../lib/dates';
import { currentDayOf, isPlanComplete } from '../lib/schedule';
import { levelFromXp } from '../lib/rules';

export interface AppApi {
  snap: Snapshot;
  loading: boolean;
  error: string | null;
  clearError: () => void;
  storeMode: 'local' | 'supabase' | null;
  xp: number;
  level: ReturnType<typeof levelFromXp>;
  streak: StreakInfo;
  currentDay: DayPlan;
  planComplete: boolean;
  completeTask: (dayId: string, taskIndex: number, done: boolean, task: Task) => Promise<void>;
  finishQuiz: (session: QuizSession, minutes: number) => Promise<number>;
  updateRef: (refId: string, status: RefStatus, note: string) => Promise<void>;
  toggleFreezeDay: (dateISO: string) => Promise<void>;
  updateProfile: (patch: Partial<Profile>) => Promise<void>;
  recordMock: (m: MockExam) => Promise<void>;
  resetAll: () => Promise<void>;
  importJson: (text: string) => Promise<void>;
  exportJson: () => string;
}

const AppContext = createContext<AppApi | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [storeMode, setStoreMode] = useState<'local' | 'supabase' | null>(null);
  const storeRef = useRef<Store | null>(null);
  const snapRef = useRef<Snapshot | null>(null);

  const apply = useCallback((next: Snapshot) => {
    snapRef.current = next;
    setSnap(next);
  }, []);

  useEffect(() => {
    let cancelled = false;
    if (!auth.email) {
      setLoading(false);
      apply(defaultSnapshot(''));
      return;
    }
    (async () => {
      setLoading(true);
      setError(null);
      const store = createStore({ email: auth.email ?? '', userId: auth.userId ?? undefined, client: auth.client });
      storeRef.current = store;
      setStoreMode(store.mode);
      try {
        const s = await store.load();
        if (!cancelled) apply(s);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth.email, auth.userId, auth.client, apply]);

  const run = useCallback(
    async <T extends { snap: Snapshot; ops: Ops }>(fn: (s: Snapshot) => T): Promise<T | null> => {
      const cur = snapRef.current;
      const store = storeRef.current;
      if (!cur || !store) return null;
      const result = fn(cur);
      apply(result.snap);
      try {
        await store.persist(result.snap, result.ops);
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
        try {
          const fresh = await store.load();
          apply(fresh);
        } catch {
          /* giữ nguyên trạng thái hiện tại */
        }
      }
      return result;
    },
    [apply],
  );

  const completeTask = useCallback(
    async (dayId: string, taskIndex: number, done: boolean, task: Task) => {
      await run((s) => setTaskDone(s, dayId, taskIndex, done, task));
    },
    [run],
  );

  const finishQuiz = useCallback(
    async (session: QuizSession, minutes: number): Promise<number> => {
      const r = await run((s) => saveQuizSession(s, session, minutes));
      return r?.awardedXp ?? 0;
    },
    [run],
  );

  const updateRef = useCallback(
    async (refId: string, status: RefStatus, note: string) => {
      await run((s) => setRefProgress(s, refId, status, note));
    },
    [run],
  );

  const toggleFreezeDay = useCallback(
    async (dateISO: string) => {
      await run((s) => toggleFreeze(s, dateISO));
    },
    [run],
  );

  const updateProfile = useCallback(
    async (patch: Partial<Profile>) => {
      await run((s) => saveProfile(s, patch));
    },
    [run],
  );

  const recordMock = useCallback(
    async (m: MockExam) => {
      await run((s) => addMock(s, m));
    },
    [run],
  );

  const resetAll = useCallback(async () => {
    const store = storeRef.current;
    if (!store) return;
    try {
      const s = await store.reset();
      apply(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [apply]);

  const importJson = useCallback(
    async (text: string) => {
      const store = storeRef.current;
      if (!store) return;
      try {
        const parsed = JSON.parse(text) as Snapshot;
        if (!parsed || typeof parsed !== 'object' || !parsed.profile) {
          throw new Error('File JSON không đúng định dạng sao lưu.');
        }
        const s = await store.importSnapshot(parsed);
        apply(s);
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      }
    },
    [apply],
  );

  const exportJson = useCallback(() => {
    const cur = snapRef.current;
    return JSON.stringify(cur, null, 2);
  }, []);

  const value = useMemo<AppApi>(() => {
    const s = snap ?? defaultSnapshot(auth.email ?? '');
    const xp = totalXp(s);
    const today = todayISO();
    const current = currentDayOf(s);
    return {
      snap: s,
      loading,
      error,
      clearError: () => setError(null),
      storeMode,
      xp,
      level: levelFromXp(xp),
      streak: computeStreak(Object.keys(s.activities), s.freezes, today, s.profile.startDate),
      currentDay: current,
      planComplete: isPlanComplete(s, current),
      completeTask,
      finishQuiz,
      updateRef,
      toggleFreezeDay,
      updateProfile,
      recordMock,
      resetAll,
      importJson,
      exportJson,
    };
  }, [
    snap,
    loading,
    error,
    storeMode,
    completeTask,
    finishQuiz,
    updateRef,
    toggleFreezeDay,
    updateProfile,
    recordMock,
    resetAll,
    importJson,
    exportJson,
    auth.email,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppApi {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp phải dùng bên trong <AppProvider>');
  return ctx;
}
