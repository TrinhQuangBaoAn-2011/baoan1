# Roadmap VAIO / IOAI — Trần Quách Bảo An

Website cá nhân biến kế hoạch 52 tuần thành hệ thống học hằng ngày kiểu Duolingo:

- 🗺️ **Lộ trình 52 tuần** — 364 ngày, mỗi ngày có danh sách nhiệm vụ riêng (lý thuyết → code → quiz → ghi chú). Lịch **cuốn theo tiến độ**: nghỉ một ngày thì bài vẫn ở đó, không bị nhảy cóc.
- 🌗 **Sáng/Tối** — nút đổi giao diện trên thanh trên, lưu lựa chọn; sticker emoji dùng một khung viền trắng cố định.
- 🏷️ **Sticker emoji hệ thống** — không tự vẽ icon mới; mọi huy hiệu dùng chung một khung cố định.
- 🧠 **Quiz mỗi ngày** — 10 câu/ngày (4 câu bài mới + câu đến hạn ôn + câu cũ), hơn 510 câu hỏi kèm giải thích, có chế độ luyện theo chủ đề và **mô phỏng có bấm giờ** (10/30/60/100 câu).
- 🔔 **Ôn tập lặp lại ngắt quãng** — câu sai quay lại sau 1 ngày, đúng thì giãn 3 → 7 → 14 → 30 ngày.
- 🔥 **Chuỗi ngày như Duolingo** — lịch tháng tô màu theo mức học, streak freeze 2 ngày/tháng.
- 📚 **Thư viện 110 tài liệu** — link chọn lọc theo từng giai đoạn, có trạng thái đọc + ghi chú.
- 🧰 **Toolkit 20 repo GitHub + 10 đoạn code** tái sử dụng cho phòng thi.
- 🏁 **Mốc thi & nhật ký mô phỏng** — đếm ngược VAIO/VOAI/IOAI/IAIO, lưu điểm từng lần làm bài.
- 📊 **Thống kê** — XP, cấp độ, độ chính xác theo từng tag, biểu đồ 60 ngày, phát hiện chủ đề yếu.

## Vì sao không bị các lỗi thường gặp?

| Lỗi thường gặp | Cách chặn trong app |
| --- | --- |
| Điểm XP tăng vô hạn khi bấm lại | Mọi XP gắn **event key duy nhất** (`task:d001:0`, `daily:2026-10-20`…). Bảng `xp_events` có khoá chính (user, event_key) ở Supabase; xử lý ở local cũng theo đúng luật đó. Tick lại hoặc làm lại quiz trong ngày ⇒ 0 XP. |
| Bỏ tick vẫn giữ điểm | Bỏ tick sẽ **thu hồi** đúng số XP + số phút đã cộng (trừ vào đúng ngày đã ghi). |
| App “quên” lịch sử học | Tiến độ ghi ngay mỗi thao tác xuống localStorage (chế độ local) hoặc Supabase (chế độ cloud); có nút **sao lưu/phục hồi JSON**. |
| Bỏ lỡ ngày học bị nhảy sang bài mới | Ngày hiện tại là **ngày đầu tiên chưa hoàn thành** (tick đủ việc + đã làm quiz), không map theo ngày lịch. Nghỉ bao lâu thì bài vẫn nằm nguyên đó. |
| Lịch streak sai khi hôm nay chưa học | Streak tính từ hôm qua nếu hôm nay chưa hoạt động, freeze nối chuỗi nhưng không cộng ngày. |
| Đề quiz đổi mỗi lần tải trang | Bộ chọn câu hỏi dùng **seed theo ngày** — mở lại vẫn đúng đề cũ. |
| Mất dữ liệu khi đổi thiết bị | Bật Supabase để đồng bộ giữa điện thoại + máy tính (xem dưới). |

## Chạy tại máy

```bash
npm install
npm run dev      # http://localhost:5173
npm test         # kiểm thử logic chống bug (XP, streak, chọn câu hỏi…)
npm run build    # kiểm tra type + build production
```

Chưa cấu hình Supabase ⇒ app chạy **chế độ local**: chỉ cho đăng nhập bằng đúng `tqbaoan2k11@gmail.com`, dữ liệu lưu trong trình duyệt.

## Chiến lược thiết bị (máy 4GB RAM, GPU yếu)

| Nơi | Dùng cho việc gì | Lưu ý |
| --- | --- | --- |
| **Máy 4GB (chính)** | Lý thuyết, bài tập, quiz, EDA dữ liệu nhỏ–vừa, scikit-learn nhỏ, ghi chú | Python 64-bit; chỉ cài numpy/pandas/scikit-learn/matplotlib. Snippet **s9** (Toolkit) có mẹo tiết kiệm RAM: `category`, `chunksize`, `del` + `gc.collect()`. |
| **Google Colab** | Toàn bộ deep learning từ tuần 20+ (CNN, transformer, fine-tune) | Miễn phí có GPU; phiên ~12h; lưu bản sao notebook vào Drive; GPU không đảm bảo. |
| **Kaggle Notebooks** | Khi Colab hết quota hoặc cần dataset lớn | ~30h GPU/tuần, lưu version tự động. |
| **Điện thoại** | Quiz hằng ngày, đọc thư viện, tick checklist | Bật Supabase để đồng bộ giữa các thiết bị. |

Code deep learning nên viết theo `device = "cuda" if torch.cuda.is_available() else "cpu"` để chạy được ở cả Colab lẫn máy yếu. Muốn chạy thử PyTorch local, cài bản CPU nhẹ: `pip install torch --index-url https://download.pytorch.org/whl/cpu`.

## Bật đăng nhập Google thật + đồng bộ (Supabase)

1. Tạo project tại [supabase.com](https://supabase.com) (region Singapore).
2. Supabase → **SQL Editor** → dán và chạy toàn bộ `supabase/schema.sql`.
   File này tạo bảng, khoá chống cộng trùng XP, và **RLS chỉ cho đúng email `tqbaoan2k11@gmail.com`**.
3. [Google Cloud Console](https://console.cloud.google.com) → tạo OAuth Client (Web application):
   - Authorized JavaScript origins: domain Vercel của bạn (và `http://localhost:5173` khi thử).
   - Authorized redirect URI: `https://<project-ref>.supabase.co/auth/v1/callback`.
   - Giữ màn hình consent ở **Testing** và thêm test user `tqbaoan2k11@gmail.com`.
4. Supabase → Authentication → Providers → **Google**: dán Client ID/Secret. Ở URL Configuration thêm domain Vercel vào Redirect URLs.
5. Tạo `.env.local`:

```env
VITE_SUPABASE_URL=https://<project-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<anon key>
```

6. Deploy lại. App tự chuyển sang đăng nhập Google; người khác đăng nhập cũng **không đọc được dữ liệu** nhờ RLS.

## Deploy lên Vercel

**Cách A — Vercel Drop (khuyên dùng, không cần Git/CLI):**

1. Dùng folder sạch `vaio-website-vercel` hoặc file `vaio-website-vercel.zip` trong `E:\Bảo An\DEPLOY VAIO\` (agent tạo sẵn — chi tiết trong `HUONG-DAN-DEPLOY.md`).
2. Mở https://vercel.com/drop → kéo-thả folder (hoặc chọn file zip) → chọn team + đặt tên project → **Deploy**. Vercel tự nhận Vite và build.
3. Muốn bật Supabase: Settings → Environment Variables → thêm 2 biến như trên → Redeploy.
4. Mở link trên điện thoại → “Thêm vào màn hình chính” (đã có manifest PWA) để dùng như app.

**Cách B — GitHub / CLI** (khi máy đã cài Git): đẩy repo lên GitHub rồi Import Project trên Vercel, hoặc chạy `npx vercel --prod` trong thư mục dự án.

## Cấu trúc

```
src/
  data/curriculum.ts     # 52 tuần × 7 ngày (sửa lộ trình ở đây)
  data/questions/        # ngân hàng câu hỏi (6 phần, thêm câu mới rất dễ)
  data/refs.ts           # 110 tài liệu tham khảo
  data/toolkit.ts        # repo GitHub + snippet
  lib/mutations.ts       # toàn bộ luật XP / activity (chống bug ở một chỗ duy nhất)
  lib/quizEngine.ts      # chọn câu hỏi, chấm điểm, lịch ôn tập
  lib/schedule.ts        # ngày hiện tại = ngày đầu tiên chưa hoàn thành
  lib/theme.ts           # sáng/tối, lưu lựa chọn
  lib/streak.ts          # tính chuỗi ngày
  lib/storage/           # local (localStorage) + supabase (Postgres)
  pages/                 # Today, Roadmap, Quiz, Calendar, Library, Toolkit, Exams, Stats, Settings
supabase/schema.sql      # chạy một lần trên Supabase
```

## Thêm câu hỏi mới

Mở file trong `src/data/questions/`, thêm object theo mẫu:

```ts
{ id: 'py31', tags: ['python'], type: 'mcq', q: 'Câu hỏi?',
  options: ['A', 'B', 'C', 'D'], a: 2, why: 'Giải thích ngắn.' }
```

`type`: `mcq` (chọn 1, `a` là index), `multi` (`a` là mảng index), `fill` (`a` là mảng đáp án chấp nhận).
Tag phải khớp tag của tuần trong `curriculum.ts` để quiz ngày lấy đúng câu.
