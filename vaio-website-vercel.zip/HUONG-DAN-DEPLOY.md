# Hướng dẫn đưa web lên Vercel (không cần Git, không cần cài gì)

> Chuẩn bị sẵn: folder **`vaio-website-vercel`** (bản sạch, không chứa node_modules) và file **`vaio-website-vercel.zip`** nằm trong `E:\Bảo An\DEPLOY VAIO\`.

## Bạn cần có

- Tài khoản Vercel miễn phí — đăng ký tại https://vercel.com/signup (nhanh nhất là "Continue with Google" bằng chính Gmail của bạn).
- Trình duyệt trên máy tính (kéo-thả folder) hoặc điện thoại (chọn file .zip).

## Cách 1 — Vercel Drop (khuyên dùng, ~3 phút)

1. Mở https://vercel.com/drop và đăng nhập.
2. **Kéo folder `vaio-website-vercel`** (hoặc file `vaio-website-vercel.zip`) thả vào trang. Nếu dùng điện thoại: bấm nút chọn file rồi chọn zip.
3. Chọn team (thường là tài khoản cá nhân của bạn), đặt tên project: `vaio-roadmap` (nếu trùng tên thì dùng `vaio-roadmap-2k11`).
4. Bấm **Deploy** → chờ khoảng 1–2 phút (Vercel tự nhận Vite và tự build).
5. Nhận link dạng `https://vaio-roadmap.vercel.app` → mở trên điện thoại → menu trình duyệt → **"Thêm vào màn hình chính"** để dùng như app.

**Sau này cập nhật code:** nhờ agent tạo lại folder/zip → kéo-thả lại vào đúng project đó trên Vercel (Drop vào project cũ sẽ tạo bản production mới).

## Cách 2 — Thêm Supabase sau khi đã có project

Khi đã tạo xong Supabase (xem hướng dẫn 6 bước agent đã gửi):

1. Vercel → Project `vaio-roadmap` → **Settings → Environment Variables** → thêm 2 biến:
   - `VITE_SUPABASE_URL` = Project URL của bạn
   - `VITE_SUPABASE_ANON_KEY` = anon public key
2. Vercel → **Deployments** → bấm **Redeploy** (hoặc kéo-thả lại folder).
3. Supabase → **Authentication → URL Configuration** → thêm link `https://vaio-roadmap.vercel.app` vào **Redirect URLs**; đổi **Site URL** thành link Vercel.
4. Google Cloud Console → OAuth Client → thêm link Vercel vào **Authorized JavaScript origins**.

## Cách 3 — Vercel CLI (nếu sau này muốn deploy tự động)

```bash
cd "E:\Bảo An\DEPLOY VAIO\vaio-website-vercel"
npx vercel login
npx vercel --prod
```

## Lưu ý

- Folder gộp **không chứa `node_modules`** (Vercel tự cài khi build) nhờ vậy upload nhanh; **không chứa** dữ liệu riêng tư nào.
- File `vercel.json` đã cấu hình sẵn cho app React Router (mọi đường dẫn đều trỏ về index.html).
- App vẫn chạy được **chế độ local** ngay sau khi deploy: đăng nhập bằng cách gõ `tqbaoan2k11@gmail.com`. Bật Supabase xong thì tự chuyển sang đăng nhập Google thật + đồng bộ nhiều thiết bị.
