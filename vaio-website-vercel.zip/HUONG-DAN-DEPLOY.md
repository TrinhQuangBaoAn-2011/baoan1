# Hướng dẫn đưa web lên Vercel (không cần Git)

> Có 2 kiểu deploy. **Kiểu A (khuyên dùng)** upload bản đã build sẵn — Vercel không cài `node_modules`, không chạy build, nên không thể lỗi `vite: command not found` hay `vue-cli-service`.
>
> **Kiểu B** để Vercel tự build từ source — chỉ dùng khi bạn muốn khai báo biến môi trường trên Vercel.

## Bạn cần có

- Tài khoản Vercel miễn phí — đăng ký tại https://vercel.com/signup (nhanh nhất là "Continue with Google").
- Trình duyệt trên máy tính hoặc điện thoại.

## Cách A — Vercel Drop với bản tĩnh (khuyên dùng, ~3 phút)

### Tạo file zip

Mở Command Prompt / PowerShell tại thư mục dự án:

```bat
npm run build:static
```

Lệnh này tự build, rồi tạo:

```
E:\Bảo An\DEPLOY VAIO\vaio-website-static.zip
```

Mỗi lần chạy còn lưu thêm một bản có ngày giờ, ví dụ `vaio-website-static-20261022-1845.zip`.

### Đưa lên Vercel

1. Mở https://vercel.com/drop và đăng nhập.
2. Kéo-thả file **`vaio-website-static.zip`**. Nếu dùng điện thoại: bấm nút chọn file rồi chọn zip.
3. Chọn team (thường là tài khoản cá nhân), đặt tên project mới, ví dụ `vaio-roadmap`.
4. Bấm **Deploy** → nhận link dạng `https://vaio-roadmap.vercel.app`.
5. Mở link trên điện thoại → menu trình duyệt → **"Thêm vào màn hình chính"**.

**Cập nhật code:** chạy lại `npm run build:static` → kéo-thả zip mới vào đúng project cũ (Vercel Drop tạo bản production mới).

### Bật Supabase với bản tĩnh

Bản tĩnh đã nhúng key lúc build, nên **Environment Variables trên Vercel không có tác dụng**. Làm như sau:

1. Tạo file `.env.local` trong thư mục dự án:
   ```env
   VITE_SUPABASE_URL=https://<project-ref>.supabase.co
   VITE_SUPABASE_ANON_KEY=<anon key>
   ```
2. Chạy lại `npm run build:static`.
3. Upload zip mới lên Vercel Drop.
4. Supabase → **Authentication → URL Configuration** → thêm link Vercel vào **Redirect URLs**; đổi **Site URL** thành link Vercel.
5. Google Cloud Console → OAuth Client → thêm link Vercel vào **Authorized JavaScript origins**.

## Cách B — Để Vercel tự build từ source

Dùng folder `vaio-website-vercel` hoặc `vaio-website-vercel.zip` trong `E:\Bảo An\DEPLOY VAIO\`.

Trong Vercel → Project → **Settings → Build & Development Settings**:

| Mục | Giá trị |
| --- | --- |
| Framework Preset | `Vite` |
| Install Command | `npm install --include=dev` |
| Build Command | `npm run build` |
| Output Directory | `dist` |

Sau đó kéo-thả folder/zip vào https://vercel.com/drop, hoặc **Deployments → Redeploy**.

- Không đặt biến `NODE_ENV=production` trong Environment Variables, vì npm sẽ bỏ qua `devDependencies` (trong đó có `vite`).
- Nếu project từng deploy một app Vue, đổi **Framework Preset** từ `Vue.js` sang `Vite`, nếu không Vercel sẽ chạy `vue-cli-service build` và báo exit 127.
- Với cách này, thêm `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` trong **Settings → Environment Variables** rồi Redeploy.

## Cách C — Vercel CLI (khi đã cài Node)

```bat
cd "E:\Bảo An\DEPLOY VAIO\vaio-website-vercel"
npx vercel login
npx vercel --prod
```

## Lưu ý

- Bản tĩnh **không chứa** `node_modules`, `.env.local`, hay dữ liệu riêng tư.
- `vercel.json` đã cấu hình rewrite cho React Router, cache cho `/assets`, và vài header bảo mật cơ bản.
- App chạy **chế độ local** ngay sau khi deploy: đăng nhập bằng `tqbaoan2k11@gmail.com`. Bật Supabase thì chuyển sang đăng nhập Google thật + đồng bộ nhiều thiết bị.
- Xem bản đang chạy bằng dòng **“Bản build: …”** ở cuối thẻ tài khoản trong **Cài đặt**.
