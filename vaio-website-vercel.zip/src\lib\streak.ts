import { addDays, diffDays } from './dates';

export interface StreakInfo {
  current: number;
  longest: number;
  studiedToday: boolean;
}

/**
 * Tính streak từ tập ngày có hoạt động + tập ngày freeze.
 * - Freeze không cộng streak nhưng không làm đứt chuỗi.
 * - Hôm nay chưa học vẫn chưa bị coi là đứt (streak tính đến hôm qua).
 */
export function computeStreak(
  activityDates: Iterable<string>,
  freezes: Iterable<string>,
  today: string,
  startDate?: string,
): StreakInfo {
  const active = new Set(activityDates);
  const frozen = new Set(freezes);
  const studiedToday = active.has(today);

  // ----- longest: quét các đoạn liên tiếp (activity | freeze) -----
  const all = new Set<string>([...active, ...frozen]);
  if (startDate) {
    for (const d of [...all]) {
      if (diffDays(startDate, d) < 0) all.delete(d);
    }
  }
  const sorted = [...all].sort();
  let longest = 0;
  let run = 0;
  let prev: string | null = null;
  for (const d of sorted) {
    if (prev !== null && diffDays(prev, d) === 1) {
      if (active.has(d)) run += 1;
    } else {
      run = active.has(d) ? 1 : 0;
    }
    if (run > longest) longest = run;
    prev = d;
  }

  // ----- current: đi ngược từ hôm nay (hoặc hôm qua nếu hôm nay chưa học) -----
  let anchor = today;
  if (!active.has(anchor) && !frozen.has(anchor)) {
    anchor = addDays(today, -1);
    if (!active.has(anchor) && !frozen.has(anchor)) {
      return { current: 0, longest, studiedToday };
    }
  }
  let current = 0;
  let cur = anchor;
  let guard = 0;
  while (guard < 4000) {
    if (active.has(cur)) {
      current += 1;
    } else if (!frozen.has(cur)) {
      break;
    }
    if (startDate && diffDays(startDate, cur) <= 0 && !active.has(cur) && !frozen.has(cur)) break;
    cur = addDays(cur, -1);
    guard++;
  }
  return { current, longest, studiedToday };
}

/** Chuỗi ngày liên tiếp gần nhất có hoạt động (để tô màu lịch). */
export function activityLevel(activity: { minutes: number; tasks: number; quizzes: number } | undefined): 0 | 1 | 2 {
  if (!activity) return 0;
  if (activity.tasks >= 2 && activity.quizzes >= 1) return 2;
  if (activity.minutes > 0 || activity.tasks > 0 || activity.quizzes > 0) return 1;
  return 0;
}
