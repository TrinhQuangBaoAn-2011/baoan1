import type { Question } from '../../lib/types';
import { PART1 } from './part1';
import { PART2 } from './part2';
import { PART3 } from './part3';
import { PART4 } from './part4';
import { PART5 } from './part5';
import { PART6 } from './part6';

/** Toàn bộ ngân hàng câu hỏi (~510 câu, phủ mọi chủ đề của lộ trình). */
export const QUESTIONS: Question[] = [...PART1, ...PART2, ...PART3, ...PART4, ...PART5, ...PART6];

export const QUESTION_INDEX: Record<string, Question> = Object.fromEntries(
  QUESTIONS.map((q) => [q.id, q]),
);

export const ALL_TAGS: string[] = [...new Set(QUESTIONS.flatMap((q) => q.tags))].sort();

export function questionsByTag(tag: string): Question[] {
  if (tag === 'all') return QUESTIONS;
  return QUESTIONS.filter((q) => q.tags.includes(tag));
}
