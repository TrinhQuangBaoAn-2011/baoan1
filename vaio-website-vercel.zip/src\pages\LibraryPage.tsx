import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { REFS, REF_CATEGORIES, type RefCategory } from '../data/refs';
import type { RefStatus } from '../lib/types';
import { ProgressBar } from '../components/ui';

export default function LibraryPage() {
  const { snap, updateRef } = useApp();
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState<RefCategory | 'all'>('all');
  const [pri, setPri] = useState<'all' | 1 | 2 | 3>('all');
  const [status, setStatus] = useState<RefStatus | 'all'>('all');
  const [noteDraft, setNoteDraft] = useState<Record<string, string>>({});

  const filtered = useMemo(() => {
    const s = search.toLowerCase();
    return REFS.filter((r) => {
      if (cat !== 'all' && r.cat !== cat) return false;
      if (pri !== 'all' && r.pri !== pri) return false;
      const st = snap.refs[r.id]?.status ?? 'todo';
      if (status !== 'all' && st !== status) return false;
      if (s && !r.title.toLowerCase().includes(s) && !r.url.toLowerCase().includes(s)) return false;
      return true;
    });
  }, [search, cat, pri, status, snap.refs]);

  const doneCount = REFS.filter((r) => snap.refs[r.id]?.status === 'done').length;
  const doingCount = REFS.filter((r) => snap.refs[r.id]?.status === 'doing').length;

  function randomPick() {
    const pool = filtered.length ? filtered : REFS;
    const r = pool[Math.floor(Math.random() * pool.length)];
    window.open(r.url, '_blank');
  }

  return (
    <>
      <div className="card">
        <div className="row between">
          <div>
            <h2 style={{ margin: 0 }}>📚 Thư viện tri thức ({REFS.length} mục)</h2>
            <p className="muted small" style={{ margin: '4px 0 0' }}>
              Tài liệu đọc thêm cho thời gian rảnh. Đánh dấu trạng thái và ghi chú để biến link thành kiến thức thật.
            </p>
          </div>
          <button className="btn sm" onClick={randomPick}>
            🎲 Mở ngẫu nhiên
          </button>
        </div>
        <div style={{ marginTop: 10 }}>
          <ProgressBar value={doneCount} max={REFS.length} />
          <div className="tiny muted" style={{ marginTop: 4 }}>
            Đã đọc xong {doneCount}/{REFS.length} · đang đọc {doingCount}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="grid cols-4">
          <label className="field">
            <span>Tìm kiếm</span>
            <input className="input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ví dụ: PyTorch, toán, CNN…" />
          </label>
          <label className="field">
            <span>Nhóm</span>
            <select value={cat} onChange={(e) => setCat(e.target.value as RefCategory | 'all')}>
              <option value="all">Tất cả</option>
              {REF_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            <span>Ưu tiên</span>
            <select value={String(pri)} onChange={(e) => setPri(e.target.value === 'all' ? 'all' : (Number(e.target.value) as 1 | 2 | 3))}>
              <option value="all">Tất cả</option>
              <option value="3">3 — bắt buộc</option>
              <option value="2">2 — nên học</option>
              <option value="1">1 — nếu rảnh</option>
            </select>
          </label>
          <label className="field">
            <span>Trạng thái</span>
            <select value={status} onChange={(e) => setStatus(e.target.value as RefStatus | 'all')}>
              <option value="all">Tất cả</option>
              <option value="todo">Chưa đọc</option>
              <option value="doing">Đang đọc</option>
              <option value="done">Đã xong</option>
            </select>
          </label>
        </div>
      </div>

      {filtered.map((r) => {
        const p = snap.refs[r.id];
        const st = p?.status ?? 'todo';
        return (
          <div key={r.id} className="card">
            <div className="row between">
              <div>
                <b>{r.title}</b>
                <div className="tiny muted">
                  <span className="badge blue">{r.cat}</span>{' '}
                  <span className={`badge ${r.pri === 3 ? 'red' : r.pri === 2 ? 'amber' : ''}`}>ưu tiên {r.pri}</span> · gợi ý: {r.when}
                </div>
              </div>
              <div className="row">
                <select
                  value={st}
                  onChange={(e) => void updateRef(r.id, e.target.value as RefStatus, p?.note ?? '')}
                  style={{ width: 140 }}
                >
                  <option value="todo">Chưa đọc</option>
                  <option value="doing">Đang đọc</option>
                  <option value="done">Đã xong</option>
                </select>
                <a className="btn sm primary" href={r.url} target="_blank" rel="noreferrer">
                  Mở
                </a>
              </div>
            </div>
            <input
              className="input"
              style={{ marginTop: 8 }}
              placeholder="Ghi chú: điều đáng nhớ nhất…"
              value={noteDraft[r.id] ?? p?.note ?? ''}
              onChange={(e) => setNoteDraft((d) => ({ ...d, [r.id]: e.target.value }))}
              onBlur={() => void updateRef(r.id, st, (noteDraft[r.id] ?? p?.note ?? '').trim())}
            />
          </div>
        );
      })}
      {filtered.length === 0 ? <div className="card center muted">Không có mục nào khớp bộ lọc.</div> : null}
    </>
  );
}
