import type { Activity, MockExam, Profile, QuizSession, RefProgress, RefStatus, Snapshot, Task } from './types';
import { quizEventKey, quizXp } from './rules';
import { nextReview } from './quizEngine';
import { todayISO } from './dates';

export interface Ops {
  task?: { dayId: string; taskIndex: number; done: boolean; date: string };
  xpKeys: string[];
  activityDates: string[];
  quizzes: QuizSession[];
  reviewChanged: string[];
  refsChanged: string[];
  freezesChanged: string[];
  profileChanged: boolean;
  mocks: MockExam[];
}

export const emptyOps = (): Ops => ({
  xpKeys: [],
  activityDates: [],
  quizzes: [],
  reviewChanged: [],
  refsChanged: [],
  freezesChanged: [],
  profileChanged: false,
  mocks: [],
});

export function cloneSnapshot(s: Snapshot): Snapshot {
  return JSON.parse(JSON.stringify(s)) as Snapshot;
}

export function defaultProfile(email: string): Profile {
  return {
    email,
    name: 'Bảo An',
    startDate: '2026-10-20',
    examDates: { vaio: '2027-10-17', voai: '2027-04-15' },
    dailyGoalMin: 90,
  };
}

export function defaultSnapshot(email: string): Snapshot {
  return {
    profile: defaultProfile(email),
    tasks: {},
    xpEvents: {},
    quizzes: [],
    review: {},
    refs: {},
    activities: {},
    freezes: [],
    mocks: [],
  };
}

function bumpActivity(snap: Snapshot, date: string, dXp: number, dMin: number, dTasks: number, dQuizzes: number) {
  const cur: Activity = snap.activities[date] ?? { date, xp: 0, minutes: 0, tasks: 0, quizzes: 0 };
  const next: Activity = {
    date,
    xp: Math.max(0, cur.xp + dXp),
    minutes: Math.max(0, cur.minutes + dMin),
    tasks: Math.max(0, cur.tasks + dTasks),
    quizzes: Math.max(0, cur.quizzes + dQuizzes),
  };
  if (next.xp === 0 && next.minutes === 0 && next.tasks === 0 && next.quizzes === 0) {
    delete snap.activities[date];
  } else {
    snap.activities[date] = next;
  }
}

/**
 * Tick / bỏ tick một nhiệm vụ.
 * - XP gắn với event key duy nhất `task:<dayId>:<index>` nên tick đi tick lại KHÔNG cộng thêm.
 * - Bỏ tick sẽ thu hồi đúng số XP/ phút đã cộng trước đó.
 */
export function setTaskDone(
  snap: Snapshot,
  dayId: string,
  taskIndex: number,
  done: boolean,
  task: Task,
  dateISO = todayISO(),
): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  const key = `task:${dayId}:${taskIndex}`;
  const doneList = new Set(s.tasks[dayId] ?? []);

  if (done) {
    if (doneList.has(taskIndex)) return { snap, ops };
    doneList.add(taskIndex);
    s.tasks[dayId] = [...doneList].sort((a, b) => a - b);
    if (!s.xpEvents[key]) {
      s.xpEvents[key] = { key, amount: task.xp, date: dateISO, source: `task:${dayId}` };
      ops.xpKeys.push(key);
      bumpActivity(s, dateISO, task.xp, task.minutes, 1, 0);
      ops.activityDates.push(dateISO);
    } else {
      bumpActivity(s, dateISO, 0, task.minutes, 1, 0);
      ops.activityDates.push(dateISO);
    }
  } else {
    if (!doneList.has(taskIndex)) return { snap, ops };
    doneList.delete(taskIndex);
    s.tasks[dayId] = [...doneList].sort((a, b) => a - b);
    const ev = s.xpEvents[key];
    if (ev) {
      delete s.xpEvents[key];
      ops.xpKeys.push(key);
      bumpActivity(s, ev.date, -ev.amount, -task.minutes, -1, 0);
      ops.activityDates.push(ev.date);
    }
  }
  ops.task = { dayId, taskIndex, done, date: dateISO };
  return { snap: s, ops };
}

/**
 * Lưu một phiên quiz. XP được cấp 1 lần/ngày cho mỗi loại (daily/fast/review/mock),
 * nhờ event key duy nhất -> làm lại quiz không tăng điểm vô hạn.
 */
export function saveQuizSession(
  snap: Snapshot,
  session: QuizSession,
  minutes: number,
  dateISO = todayISO(),
): { snap: Snapshot; ops: Ops; awardedXp: number } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  s.quizzes = [session, ...s.quizzes].slice(0, 1000);
  ops.quizzes.push(session);

  const key = quizEventKey(session.kind, dateISO, session.id);
  let awarded = 0;
  const wanted = quizXp(session.kind, session.score, session.total);
  if (wanted > 0 && !s.xpEvents[key]) {
    s.xpEvents[key] = { key, amount: wanted, date: dateISO, source: `quiz:${session.kind}` };
    ops.xpKeys.push(key);
    awarded = wanted;
  }

  bumpActivity(s, dateISO, awarded, Math.max(1, Math.round(minutes)), 0, 1);
  ops.activityDates.push(dateISO);

  for (const d of session.details) {
    const item = nextReview(s.review[d.qid], d.correct, dateISO);
    s.review[d.qid] = item;
    ops.reviewChanged.push(d.qid);
  }
  return { snap: s, ops, awardedXp: awarded };
}

export function setReviewItem(snap: Snapshot, qid: string, correct: boolean, dateISO = todayISO()): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  s.review[qid] = nextReview(s.review[qid], correct, dateISO);
  ops.reviewChanged.push(qid);
  return { snap: s, ops };
}

export function setRefProgress(
  snap: Snapshot,
  refId: string,
  status: RefStatus,
  note: string,
): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  const prev = s.refs[refId];
  if (!prev && status === 'todo' && note === '') return { snap, ops };
  s.refs[refId] = { status, note, updatedAt: new Date().toISOString() } satisfies RefProgress;
  ops.refsChanged.push(refId);
  return { snap: s, ops };
}

export function toggleFreeze(snap: Snapshot, dateISO: string): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  const has = s.freezes.includes(dateISO);
  s.freezes = has ? s.freezes.filter((d) => d !== dateISO) : [...s.freezes, dateISO].sort();
  ops.freezesChanged.push(dateISO);
  return { snap: s, ops };
}

export function saveProfile(snap: Snapshot, patch: Partial<Profile>): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  s.profile = { ...s.profile, ...patch, examDates: { ...s.profile.examDates, ...(patch.examDates ?? {}) } };
  ops.profileChanged = true;
  return { snap: s, ops };
}

export function addMock(snap: Snapshot, m: MockExam): { snap: Snapshot; ops: Ops } {
  const s = cloneSnapshot(snap);
  const ops = emptyOps();
  s.mocks = [m, ...s.mocks].slice(0, 200);
  ops.mocks.push(m);
  return { snap: s, ops };
}

export function totalXp(snap: Snapshot): number {
  return Object.values(snap.xpEvents).reduce((sum, e) => sum + e.amount, 0);
}

export function quizAccuracyByTag(snap: Snapshot): Record<string, { correct: number; total: number }> {
  const out: Record<string, { correct: number; total: number }> = {};
  for (const session of snap.quizzes) {
    for (const d of session.details) {
      // cộng theo tag của session là gần đúng; chi tiết theo câu xử lý ở trang Thống kê qua question bank
      const tags = session.tags.length ? session.tags : ['khác'];
      for (const t of tags) {
        out[t] = out[t] ?? { correct: 0, total: 0 };
        out[t].total += 1;
        if (d.correct) out[t].correct += 1;
      }
    }
  }
  return out;
}
