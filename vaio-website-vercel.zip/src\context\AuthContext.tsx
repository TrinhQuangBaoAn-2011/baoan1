import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { ALLOWED_EMAIL } from '../lib/types';
import { supabaseConfig } from '../lib/storage';

const LOCAL_SESSION_KEY = 'vaio-local-session-v1';

export interface AuthState {
  status: 'loading' | 'anon' | 'authed';
  mode: 'supabase' | 'local';
  email: string | null;
  userId: string | null;
  client: SupabaseClient | null;
  error: string | null;
  /** Đăng nhập: chế độ Supabase mở Google OAuth; chế độ local kiểm tra đúng email. */
  signIn: (email?: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

const cfg = supabaseConfig();
const supabase: SupabaseClient | null = cfg ? createClient(cfg.url, cfg.key) : null;

export function AuthProvider({ children }: { children: ReactNode }) {
  const mode: 'supabase' | 'local' = supabase ? 'supabase' : 'local';
  const [status, setStatus] = useState<AuthState['status']>('loading');
  const [email, setEmail] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let unsub: (() => void) | undefined;
    (async () => {
      if (supabase) {
        const { data } = await supabase.auth.getSession();
        const session = data.session;
        if (session?.user) {
          if ((session.user.email ?? '').toLowerCase() === ALLOWED_EMAIL) {
            setEmail(session.user.email ?? null);
            setUserId(session.user.id);
            setStatus('authed');
          } else {
            await supabase.auth.signOut();
            setError(`Tài khoản ${session.user.email} không được phép. Chỉ ${ALLOWED_EMAIL} mới vào được.`);
            setStatus('anon');
          }
        } else {
          setStatus('anon');
        }
        const sub = supabase.auth.onAuthStateChange(async (_event, sess) => {
          if (sess?.user) {
            if ((sess.user.email ?? '').toLowerCase() === ALLOWED_EMAIL) {
              setEmail(sess.user.email ?? null);
              setUserId(sess.user.id);
              setStatus('authed');
              setError(null);
            } else {
              await supabase.auth.signOut();
              setError(`Tài khoản ${sess.user.email} không được phép. Chỉ ${ALLOWED_EMAIL} mới vào được.`);
              setStatus('anon');
            }
          } else {
            setEmail(null);
            setUserId(null);
            setStatus('anon');
          }
        });
        unsub = () => sub.data.subscription.unsubscribe();
      } else {
        const saved = localStorage.getItem(LOCAL_SESSION_KEY);
        if (saved && saved.toLowerCase() === ALLOWED_EMAIL) {
          setEmail(saved);
          setStatus('authed');
        } else {
          setStatus('anon');
        }
      }
    })();
    return () => unsub?.();
  }, []);

  const signIn = useCallback(
    async (inputEmail?: string) => {
      setError(null);
      if (supabase) {
        const { error: err } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: { redirectTo: window.location.origin },
        });
        if (err) setError(err.message);
        return;
      }
      const e = (inputEmail ?? '').trim().toLowerCase();
      if (e !== ALLOWED_EMAIL) {
        setError(`Email không đúng. Chỉ tài khoản ${ALLOWED_EMAIL} được vào.`);
        return;
      }
      localStorage.setItem(LOCAL_SESSION_KEY, e);
      setEmail(e);
      setStatus('authed');
    },
    [mode],
  );

  const signOut = useCallback(async () => {
    if (supabase) {
      await supabase.auth.signOut();
    } else {
      localStorage.removeItem(LOCAL_SESSION_KEY);
    }
    setEmail(null);
    setUserId(null);
    setStatus('anon');
  }, [mode]);

  const value = useMemo<AuthState>(
    () => ({ status, mode, email, userId, client: supabase, error, signIn, signOut }),
    [status, mode, email, userId, error, signIn, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth phải dùng bên trong <AuthProvider>');
  return ctx;
}
