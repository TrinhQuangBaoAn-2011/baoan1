import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ALLOWED_EMAIL } from '../lib/types';
import { Sticker } from '../components/ui';

export default function Login() {
  const { mode, signIn, error } = useAuth();
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleLocal(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    await signIn(email);
    setBusy(false);
  }

  async function handleGoogle() {
    setBusy(true);
    await signIn();
    setBusy(false);
  }

  return (
    <div className="login-wrap">
      <div className="card login-card">
        <Sticker emoji="🎯" size="md" label="Mục tiêu VAIO và IOAI" />
        <h2 style={{ marginTop: 12 }}>Roadmap chinh phục VAIO / IOAI</h2>
        <p className="muted small">
          Lộ trình 52 tuần dành riêng cho <b>Trần Quách Bảo An</b> — học mỗi ngày, quiz sau mỗi bài, giữ chuỗi ngày như
          Duolingo. Chỉ một tài khoản duy nhất được vào: <b>{ALLOWED_EMAIL}</b>.
        </p>

        {error ? <div className="banner err">{error}</div> : null}

        {mode === 'supabase' ? (
          <>
            <button className="btn primary" style={{ width: '100%' }} onClick={handleGoogle} disabled={busy}>
              {busy ? 'Đang chuyển…' : '🔐 Đăng nhập bằng Google'}
            </button>
            <p className="tiny muted" style={{ marginTop: 10 }}>
              Hệ thống kiểm tra email sau khi Google xác thực. Email khác sẽ bị từ chối và tự động đăng xuất.
            </p>
          </>
        ) : (
          <form onSubmit={handleLocal}>
            <label className="field">
              <span>Gmail của bạn (chế độ local — chưa cấu hình Supabase)</span>
              <input
                className="input"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={ALLOWED_EMAIL}
                autoFocus
              />
            </label>
            <button className="btn primary" style={{ width: '100%' }} disabled={busy}>
              {busy ? 'Đang kiểm tra…' : 'Vào học'}
            </button>
            <p className="tiny muted" style={{ marginTop: 10 }}>
              Chế độ này chỉ cho phép đúng địa chỉ trên (kiểm tra ngay trong máy). Dữ liệu lưu trong trình duyệt này; muốn
              đồng bộ nhiều thiết bị, hãy cấu hình Supabase theo hướng dẫn trong mục Cài đặt sau khi vào.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
