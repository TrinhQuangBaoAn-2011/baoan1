/** Quy tắc XP — mọi mốc XP đều gắn event key duy nhất để không thể cộng trùng. */

export const XP_RULES = {
  QUIZ_DAILY: 10,
  QUIZ_FAST: 5,
  QUIZ_REVIEW: 15,
  QUIZ_PRACTICE: 0,
  QUIZ_PASS_BONUS: 5, // thêm khi đúng >= 80%
  MOCK: 100,
} as const;

export function quizXp(kind: 'daily' | 'fast' | 'review' | 'mock' | 'practice', score: number, total: number): number {
  const ratio = total > 0 ? score / total : 0;
  const bonus = ratio >= 0.8 ? XP_RULES.QUIZ_PASS_BONUS : 0;
  switch (kind) {
    case 'daily':
      return XP_RULES.QUIZ_DAILY + bonus;
    case 'fast':
      return XP_RULES.QUIZ_FAST;
    case 'review':
      return XP_RULES.QUIZ_REVIEW + bonus;
    case 'mock':
      return XP_RULES.MOCK;
    default:
      return XP_RULES.QUIZ_PRACTICE;
  }
}

/** XP chỉ được nhận 1 lần/ngày cho từng loại quiz (chống cày điểm vô hạn). */
export function quizEventKey(kind: 'daily' | 'fast' | 'review' | 'mock' | 'practice', dateISO: string, sessionId: string): string {
  if (kind === 'daily') return `daily:${dateISO}`;
  if (kind === 'fast') return `fast:${dateISO}`;
  if (kind === 'mock') return `mock:${dateISO}`;
  if (kind === 'review') return `review:${dateISO}`;
  return `practice:${sessionId}`;
}

export function tgXP(level: number): number {
  // ngưỡng XP cho các cấp kiểu Duolingo
  const thresholds = [0, 500, 1500, 3000, 5000, 8000, 12000, 20000];
  return thresholds[Math.min(level, thresholds.length - 1)];
}

export const LEVELS = ['Đồng', 'Bạc', 'Vàng', 'Ruby', 'Ngọc lục bảo', 'Zafiro', 'Kim cương', 'Huyền thoại'];

export function levelFromXp(xp: number): { level: number; name: string; next: number; progress: number } {
  let level = 0;
  for (let i = 0; i < LEVELS.length; i++) {
    if (xp >= tgXP(i)) level = i;
  }
  const cur = tgXP(level);
  const next = tgXP(Math.min(level + 1, LEVELS.length - 1));
  const progress = next > cur ? Math.min(1, (xp - cur) / (next - cur)) : 1;
  return { level, name: LEVELS[level], next, progress };
}
