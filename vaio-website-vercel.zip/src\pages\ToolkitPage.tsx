import { useMemo, useState } from 'react';
import { REPOS, SNIPPETS } from '../data/toolkit';

export default function ToolkitPage() {
  const [tab, setTab] = useState<'repo' | 'code'>('repo');
  const [cat, setCat] = useState<string>('all');
  const [copied, setCopied] = useState<string | null>(null);

  const cats = useMemo(() => [...new Set(REPOS.map((r) => r.cat))], []);
  const repos = useMemo(() => (cat === 'all' ? REPOS : REPOS.filter((r) => r.cat === cat)), [cat]);

  async function copy(id: string, code: string) {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(id);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      setCopied(null);
    }
  }

  return (
    <>
      <div className="card">
        <h2 style={{ marginTop: 0 }}>🧰 Toolkit luyện thi</h2>
        <p className="muted small" style={{ marginTop: 0 }}>
          Kho GitHub open-source và các đoạn code tái sử dụng. Trong phòng thi không có internet — hãy học cách dùng và chép
          vào “sổ tay code” cá nhân trước.
        </p>
        <div className="row">
          <button className={`btn ${tab === 'repo' ? 'primary' : ''}`} onClick={() => setTab('repo')}>
            GitHub ({REPOS.length})
          </button>
          <button className={`btn ${tab === 'code' ? 'primary' : ''}`} onClick={() => setTab('code')}>
            Đoạn code ({SNIPPETS.length})
          </button>
        </div>
      </div>

      {tab === 'repo' ? (
        <>
          <div className="card">
            <div className="row">
              <button className={`btn sm ${cat === 'all' ? 'primary' : ''}`} onClick={() => setCat('all')}>
                Tất cả
              </button>
              {cats.map((c) => (
                <button key={c} className={`btn sm ${cat === c ? 'primary' : ''}`} onClick={() => setCat(c)}>
                  {c}
                </button>
              ))}
            </div>
          </div>
          {repos.map((r) => (
            <div key={r.name} className="card">
              <div className="row between">
                <div>
                  <b>{r.name}</b>
                  <div className="tiny muted">
                    <span className="badge blue">{r.cat}</span> {r.purpose}
                  </div>
                </div>
                <a className="btn sm primary" href={r.url} target="_blank" rel="noreferrer">
                  Mở GitHub
                </a>
              </div>
              <div className="small muted" style={{ marginTop: 6 }}>
                💡 {r.note}
              </div>
            </div>
          ))}
        </>
      ) : (
        <>
          {SNIPPETS.map((s) => (
            <div key={s.id} className="card">
              <div className="row between">
                <div>
                  <b>{s.title}</b>
                  <div className="tiny muted">Dùng khi: {s.when}</div>
                </div>
                <button className="btn sm" onClick={() => void copy(s.id, s.code)}>
                  {copied === s.id ? '✅ Đã chép' : '📋 Chép code'}
                </button>
              </div>
              <pre className="code">{s.code}</pre>
            </div>
          ))}
        </>
      )}
    </>
  );
}
