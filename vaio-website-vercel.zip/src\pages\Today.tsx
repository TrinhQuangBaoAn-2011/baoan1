import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { DAYS } from '../data/curriculum';
import { formatVN, todayISO, weekdayVN } from '../lib/dates';
import { REFS } from '../data/refs';
import { hasDayQuiz } from '../lib/schedule';
import { Banner, ProgressBar, Sticker, kindBadge, KIND_LABEL } from '../components/ui';
import type { DayPlan, Task } from '../lib/types';

function TaskRow({
  day,
  task,
  index,
  done,
  quizDone,
  onToggle,
}: {
  day: DayPlan;
  task: Task;
  index: number;
  done: boolean;
  quizDone: boolean;
  onToggle: (i: number, t: Task, v: boolean) => void;
}) {
  if (task.type === 'quiz') {
    return (
      <div className={`task ${quizDone ? 'done' : ''}`}>
        <input type="checkbox" checked={quizDone} disabled readOnly aria-label={task.label} />
        <div className="task-label">
          <div>{task.label}</div>
          <div className="tiny muted">
            {quizDone
              ? 'Đã làm quiz cho bài này. Làm lại để ôn, không cộng thêm XP trong cùng ngày.'
              : 'Quiz XP được cộng 1 lần/ngày cho mỗi loại — làm lại để ôn không tăng điểm ảo.'}
          </div>
        </div>
        <Link className="btn primary sm" to={`/quiz?day=${day.id}&mode=daily`}>
          {quizDone ? 'Làm lại' : 'Bắt đầu quiz'}
        </Link>
      </div>
    );
  }
  return (
    <div className={`task ${done ? 'done' : ''}`}>
      <input
        type="checkbox"
        checked={done}
        onChange={(e) => onToggle(index, task, e.target.checked)}
        aria-label={task.label}
      />
      <div className="task-label">
        <div>{task.label}</div>
        <div className="tiny muted">
          +{task.xp} XP · ~{task.minutes} phút
          {task.type === 'mock' || task.type === 'exam' ? (
            <>
              {' · '}
              <Link to={`/quiz?day=${day.id}&mode=mock`}>mở phòng mô phỏng</Link>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export default function Today() {
  const { snap, completeTask, streak, xp, level, currentDay, planComplete } = useApp();
  const [params] = useSearchParams();
  const [viewId, setViewId] = useState<string>(() => {
    const p = params.get('day');
    return DAYS.some((d) => d.id === p) ? (p as string) : currentDay.id;
  });
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    const p = params.get('day');
    if (p && DAYS.some((d) => d.id === p)) setViewId(p);
  }, [params]);

  useEffect(() => {
    if (running) {
      timerRef.current = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    } else if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [running]);

  const day = useMemo(() => DAYS.find((d) => d.id === viewId) ?? currentDay, [viewId, currentDay]);
  const today = todayISO();
  const doneList = snap.tasks[day.id] ?? [];
  const todaySessions = snap.quizzes.filter((q) => q.startedAt.slice(0, 10) === today);
  const quizDone = hasDayQuiz(snap, day.id);
  const totalMinutes = day.tasks.reduce((s, t) => s + t.minutes, 0);
  const doneCount = day.tasks.filter((t, i) => (t.type === 'quiz' ? quizDone : doneList.includes(i))).length;
  const complete = doneCount === day.tasks.length;
  const isCurrent = day.id === currentDay.id;
  const pct = Math.round((doneCount / Math.max(1, day.tasks.length)) * 100);
  const ringStyle = {
    background: `conic-gradient(var(--primary) ${pct}%, var(--track) 0)`,
  } as CSSProperties;

  const randomRef = useMemo(() => {
    const pool = REFS.filter((r) => r.pri >= 2);
    return pool[Math.floor(Math.random() * pool.length)];
  }, [day.id]);

  async function onToggle(i: number, t: Task, v: boolean) {
    await completeTask(day.id, i, v, t);
  }

  function go(delta: number) {
    const next = DAYS[Math.min(Math.max(day.index - 1 + delta, 0), DAYS.length - 1)];
    setViewId(next.id);
  }

  const mm = String(Math.floor(seconds / 60)).padStart(2, '0');
  const ss = String(seconds % 60).padStart(2, '0');

  return (
    <>
      <section className="hero card">
        <div className="hero-main">
          <div className="eyebrow">
            {day.phase} · Tuần {day.week}/52 · {formatVN(today)} · {weekdayVN(today)}
          </div>
          <h1 className="hero-title">
            Ngày {day.index}
            <span className="hero-of">/364</span>
          </h1>
          <p className="hero-sub">{day.title}</p>
          <div className="row">
            <span className={kindBadge(day.kind)}>{KIND_LABEL[day.kind]}</span>
            <span className="badge">{day.theme}</span>
            {isCurrent ? (
              <span className="badge green">Đang học</span>
            ) : complete ? (
              <span className="badge green">Đã xong</span>
            ) : (
              <span className="badge amber">Xem trước</span>
            )}
          </div>
        </div>
        <div className="hero-side">
          <div className="ring" style={ringStyle}>
            <div className="ring-inner">
              <b>
                {doneCount}/{day.tasks.length}
              </b>
              <span>việc</span>
            </div>
          </div>
          <div className="tiny muted center">~{totalMinutes} phút</div>
        </div>
        <div className="hero-nav">
          <button className="btn sm" onClick={() => go(-1)} disabled={day.index <= 1}>
            ← Ngày trước
          </button>
          {!isCurrent ? (
            <button className="btn sm ghost" onClick={() => setViewId(currentDay.id)}>
              Về ngày đang học
            </button>
          ) : null}
          <button className="btn sm" onClick={() => go(1)} disabled={day.index >= DAYS.length}>
            Ngày sau →
          </button>
        </div>
      </section>

      {complete ? (
        <Banner kind="info">
          {planComplete && isCurrent ? (
            <span>🏆 Bạn đã hoàn thành toàn bộ 364 ngày. Giờ là lúc ôn lại và luyện đề.</span>
          ) : (
            <div className="row between">
              <span>
                ✅ Ngày {day.index} đã xong.{' '}
                {isCurrent ? 'Ngày kế tiếp đã mở.' : `Ngày đang học là Ngày ${currentDay.index}.`}
              </span>
              <Link className="btn primary sm" to={`/today?day=${currentDay.id}`}>
                {isCurrent ? 'Học tiếp' : `Mở Ngày ${currentDay.index}`} →
              </Link>
            </div>
          )}
        </Banner>
      ) : null}

      <div className="grid cols-3">
        <div className="col-span-2">
          <div className="card">
            <h3>{isCurrent ? 'Nhiệm vụ hôm nay' : `Nhiệm vụ ngày ${day.index}`}</h3>
            {day.tasks.map((t, i) => (
              <TaskRow
                key={i}
                day={day}
                task={t}
                index={i}
                done={doneList.includes(i)}
                quizDone={quizDone}
                onToggle={onToggle}
              />
            ))}
            {day.kind === 'lesson' ? (
              <p className="tiny muted" style={{ marginBottom: 0 }}>
                Gợi ý: 20 phút lý thuyết → 40 phút code → quiz → ghi chú. Hết bài vẫn còn sức thì mở mục Thư viện đọc thêm.
              </p>
            ) : null}
          </div>

          <div className="card">
            <div className="row between">
              <h3 style={{ margin: 0 }}>Đồng hồ tập trung</h3>
              <span className="tiny muted">Mục tiêu ~{snap.profile.dailyGoalMin} phút/ngày</span>
            </div>
            <div className="row" style={{ marginTop: 10 }}>
              <div className="timer">{mm}:{ss}</div>
              <button className="btn primary" onClick={() => setRunning((r) => !r)}>
                {running ? '⏸ Tạm dừng' : '▶ Bắt đầu'}
              </button>
              <button
                className="btn"
                onClick={() => {
                  setRunning(false);
                  setSeconds(0);
                }}
              >
                ↺ Đặt lại
              </button>
            </div>
          </div>
        </div>

        <div>
          <div className="card">
            <h3 className="card-title">
              <Sticker emoji="🔥" size="sm" /> Chuỗi ngày
            </h3>
            <div className="big-number">{streak.current}</div>
            <div className="small muted">
              {streak.studiedToday ? 'Hôm nay đã học — giữ vững!' : 'Học 1 việc + 1 quiz để giữ chuỗi.'}
            </div>
            <div className="tiny muted" style={{ marginTop: 6 }}>
              Kỷ lục: {streak.longest} ngày · Freeze đã dùng: {snap.freezes.length}/2 tháng này
            </div>
          </div>

          <div className="card">
            <h3 className="card-title">
              <Sticker emoji="🏅" size="sm" /> Cấp độ
            </h3>
            <div className="row between">
              <b>
                {level.name} · Cấp {level.level + 1}
              </b>
              <span className="small muted">{xp.toLocaleString('vi-VN')} XP</span>
            </div>
            <div style={{ marginTop: 8 }}>
              <ProgressBar value={Math.round(level.progress * 100)} max={100} />
            </div>
            <div className="tiny muted" style={{ marginTop: 6 }}>
              Quiz hôm nay: {todaySessions.filter((q) => q.kind !== 'practice').length} phiên
            </div>
          </div>

          <div className="card">
            <h3 className="card-title">
              <Sticker emoji="📖" size="sm" /> Đọc thêm khi rảnh
            </h3>
            <b className="small">{randomRef.title}</b>
            <div className="tiny muted">
              {randomRef.cat} · gợi ý: {randomRef.when}
            </div>
            <div className="row" style={{ marginTop: 8 }}>
              <a className="btn sm" href={randomRef.url} target="_blank" rel="noreferrer">
                Mở link
              </a>
              <Link className="btn sm ghost" to="/library">
                Thư viện
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
