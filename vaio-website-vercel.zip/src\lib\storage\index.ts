import type { SupabaseClient } from '@supabase/supabase-js';
import { createLocalStore } from './local';
import { createSupabaseStore } from './supabase';
import type { Store } from './types';

export function supabaseConfig(): { url: string; key: string } | null {
  const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
  if (url && key && url.startsWith('http')) return { url, key };
  return null;
}

export function createStore(opts: { email: string; userId?: string; client?: SupabaseClient | null }): Store {
  if (opts.client && opts.userId) {
    return createSupabaseStore(opts.client, opts.userId, opts.email);
  }
  return createLocalStore(opts.email);
}

export type { Store } from './types';
