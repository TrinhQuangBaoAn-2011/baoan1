import { describe, expect, it } from 'vitest';
import { addDays, diffDays, todayISO } from './dates';
import { computeStreak } from './streak';
import { defaultSnapshot, saveQuizSession, setTaskDone, toggleFreeze, totalXp } from './mutations';
import { buildDailyQuiz, checkAnswer, nextReview, seededShuffle } from './quizEngine';
import { currentDayOf, isDayComplete } from './schedule';
import { DAYS } from '../data/curriculum';
import type { DayPlan, Question, QuizSession, Task } from './types';

const task: Task = { type: 'read', label: 'test', xp: 10, minutes: 20 };

const q1: Question = { id: 'a', tags: ['python'], type: 'mcq', q: 'Q1', options: ['x', 'y'], a: 0, why: 'w' };
const q2: Question = { id: 'b', tags: ['python'], type: 'multi', q: 'Q2', options: ['x', 'y', 'z'], a: [0, 2], why: 'w' };
const q3: Question = { id: 'c', tags: ['numpy'], type: 'fill', q: 'Q3', a: ['np.zeros', 'zeros'], why: 'w' };

const day: DayPlan = {
  id: 'd001',
  index: 1,
  date: '2026-10-20',
  week: 1,
  phase: 'P0',
  theme: 'test',
  title: 'test day',
  kind: 'lesson',
  tags: ['python'],
  tasks: [task],
};

function session(partial: Partial<QuizSession>): QuizSession {
  return {
    id: partial.id ?? 'sess-1',
    dayId: partial.dayId ?? 'd001',
    kind: partial.kind ?? 'daily',
    startedAt: partial.startedAt ?? '2026-10-20T10:00:00.000Z',
    finishedAt: partial.finishedAt ?? '2026-10-20T10:15:00.000Z',
    score: partial.score ?? 8,
    total: partial.total ?? 10,
    tags: partial.tags ?? ['python'],
    details: partial.details ?? [
      { qid: 'a', correct: true, given: ['0'] },
      { qid: 'b', correct: false, given: ['1'] },
    ],
  };
}

describe('dates', () => {
  it('addDays/diffDays xử lý qua tháng', () => {
    expect(addDays('2026-10-31', 1)).toBe('2026-11-01');
    expect(diffDays('2026-10-20', '2026-11-01')).toBe(12);
    expect(diffDays('2026-11-01', '2026-10-20')).toBe(-12);
  });
});

describe('XP chống cộng trùng (lỗi điểm tăng vô hạn)', () => {
  it('tick lại nhiều lần không cộng thêm XP', () => {
    let s = defaultSnapshot('tqbaoan2k11@gmail.com');
    const r1 = setTaskDone(s, 'd001', 0, true, task, '2026-10-20');
    s = r1.snap;
    const xpAfterFirst = totalXp(s);
    expect(xpAfterFirst).toBe(10);

    const r2 = setTaskDone(s, 'd001', 0, true, task, '2026-10-20');
    s = r2.snap;
    expect(totalXp(s)).toBe(10);
    expect(r2.ops.xpKeys.length).toBe(0);

    const r3 = setTaskDone(s, 'd001', 0, true, task, '2026-10-20');
    s = r3.snap;
    expect(totalXp(s)).toBe(10);
  });

  it('bỏ tick sẽ thu hồi đúng số XP và số phút đã cộng', () => {
    let s = defaultSnapshot('tqbaoan2k11@gmail.com');
    s = setTaskDone(s, 'd001', 0, true, task, '2026-10-20').snap;
    expect(s.activities['2026-10-20'].minutes).toBe(20);
    s = setTaskDone(s, 'd001', 0, false, task, '2026-10-20').snap;
    expect(totalXp(s)).toBe(0);
    expect(s.activities['2026-10-20']).toBeUndefined();
  });

  it('quiz cùng loại làm lại trong ngày: lần 2 nhận 0 XP', () => {
    let s = defaultSnapshot('tqbaoan2k11@gmail.com');
    const first = saveQuizSession(s, session({ id: 'sess-1' }), 15, '2026-10-20');
    s = first.snap;
    expect(first.awardedXp).toBeGreaterThan(0);

    const second = saveQuizSession(s, session({ id: 'sess-2' }), 15, '2026-10-20');
    s = second.snap;
    expect(second.awardedXp).toBe(0);

    const otherKind = saveQuizSession(s, session({ id: 'sess-3', kind: 'review' }), 10, '2026-10-20');
    s = otherKind.snap;
    expect(otherKind.awardedXp).toBeGreaterThan(0);
    expect(s.quizzes.length).toBe(3);
  });

  it('quiz ngày khác được cộng XP bình thường', () => {
    let s = defaultSnapshot('tqbaoan2k11@gmail.com');
    s = saveQuizSession(s, session({ id: 's1' }), 15, '2026-10-20').snap;
    const day2 = saveQuizSession(s, session({ id: 's2' }), 15, '2026-10-21');
    expect(day2.awardedXp).toBeGreaterThan(0);
  });
});

describe('streak', () => {
  it('đếm chuỗi liên tiếp và hôm nay chưa học thì tính đến hôm qua', () => {
    const s = computeStreak(['2026-10-18', '2026-10-19', '2026-10-20'], [], '2026-10-20');
    expect(s.current).toBe(3);
    expect(s.studiedToday).toBe(true);

    const s2 = computeStreak(['2026-10-18', '2026-10-19'], [], '2026-10-20');
    expect(s2.current).toBe(2);
    expect(s2.studiedToday).toBe(false);

    const s3 = computeStreak(['2026-10-17'], [], '2026-10-20');
    expect(s3.current).toBe(0);
  });

  it('freeze nối chuỗi nhưng không cộng ngày', () => {
    const s = computeStreak(['2026-10-18', '2026-10-20'], ['2026-10-19'], '2026-10-20');
    expect(s.current).toBe(2);
    expect(s.longest).toBe(2);
  });

  it('toggle freeze hoạt động', () => {
    let s = defaultSnapshot('tqbaoan2k11@gmail.com');
    s = toggleFreeze(s, '2026-10-21').snap;
    expect(s.freezes).toContain('2026-10-21');
    s = toggleFreeze(s, '2026-10-21').snap;
    expect(s.freezes).not.toContain('2026-10-21');
  });
});

describe('bộ chọn câu hỏi', () => {
  it('checkAnswer đúng cho mcq/multi/fill', () => {
    expect(checkAnswer(q1, ['0'])).toBe(true);
    expect(checkAnswer(q1, ['1'])).toBe(false);
    expect(checkAnswer(q2, ['0', '2'])).toBe(true);
    expect(checkAnswer(q2, ['2', '0'])).toBe(true);
    expect(checkAnswer(q2, ['0'])).toBe(false);
    expect(checkAnswer(q3, ['NP.ZEROS  '])).toBe(true);
    expect(checkAnswer(q3, ['np.ones'])).toBe(false);
  });

  it('quiz ngày trả đủ 10 câu duy nhất và gồm câu đến hạn ôn', () => {
    const pool = [q1, q2, q3];
    const review = { a: { due: '2026-10-19', intervalIdx: 0, wrong: 1, last: 'wrong' as const } };
    const quiz = buildDailyQuiz(day, pool, review, '2026-10-20', 'daily', ['python']);
    expect(quiz.length).toBe(3); // pool nhỏ hơn 10 thì lấy hết
    expect(new Set(quiz.map((q) => q.id)).size).toBe(quiz.length);
    expect(quiz.some((q) => q.id === 'a')).toBe(true);
  });

  it('chọn câu hỏi ổn định theo seed (bấm lại không đổi đề)', () => {
    const pool = Array.from({ length: 30 }, (_, i) => ({ ...q1, id: `q${i}` }));
    const a = seededShuffle(pool, 123).map((q) => q.id);
    const b = seededShuffle(pool, 123).map((q) => q.id);
    expect(a).toEqual(b);
  });

  it('nextReview giãn cách đúng và reset khi sai', () => {
    const t = '2026-10-20';
    const r1 = nextReview(undefined, true, t);
    expect(r1.due).toBe(addDays(t, 1));
    const r2 = nextReview(r1, true, t);
    expect(r2.due).toBe(addDays(t, 3));
    const r3 = nextReview(r2, false, t);
    expect(r3.due).toBe(addDays(t, 1));
    expect(r3.wrong).toBe(1);
  });
});

describe('lịch cuốn theo tiến độ', () => {
  const first = DAYS[0];
  const nonQuiz = first.tasks.map((t, i) => (t.type === 'quiz' ? -1 : i)).filter((i) => i >= 0);

  function withTasks(indices: number[]) {
    const s = defaultSnapshot('tqbaoan2k11@gmail.com');
    s.tasks[first.id] = indices;
    return s;
  }

  it('chưa học gì thì vẫn đứng ở ngày 1, không theo ngày lịch', () => {
    expect(currentDayOf(defaultSnapshot('tqbaoan2k11@gmail.com')).id).toBe(first.id);
  });

  it('đủ việc nhưng thiếu quiz thì chưa hoàn thành ngày', () => {
    const s = withTasks(nonQuiz);
    expect(isDayComplete(s, first)).toBe(false);
    expect(currentDayOf(s).id).toBe(first.id);
  });

  it('đủ việc + đã làm quiz thì mở ngày kế', () => {
    const s = withTasks(nonQuiz);
    s.quizzes.push(session({ id: 'daily-first', dayId: first.id, kind: 'daily' }));
    expect(isDayComplete(s, first)).toBe(true);
    expect(currentDayOf(s).id).toBe(DAYS[1].id);
  });

  it('quiz của ngày khác không được tính cho ngày đang học', () => {
    const s = withTasks(nonQuiz);
    s.quizzes.push(session({ id: 'other-day', dayId: DAYS[1].id, kind: 'daily' }));
    expect(isDayComplete(s, first)).toBe(false);
  });

  it('bỏ tick một việc thì ngày hiện tại lùi lại đúng ngày đó', () => {
    let s = withTasks(nonQuiz);
    s.quizzes.push(session({ id: 'daily-first', dayId: first.id, kind: 'daily' }));
    expect(currentDayOf(s).id).toBe(DAYS[1].id);
    s.tasks[first.id] = nonQuiz.slice(1);
    expect(currentDayOf(s).id).toBe(first.id);
  });
});
