import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { useApp } from './context/AppContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Today from './pages/Today';
import Roadmap from './pages/Roadmap';
import Quiz from './pages/Quiz';
import CalendarPage from './pages/CalendarPage';
import LibraryPage from './pages/LibraryPage';
import ToolkitPage from './pages/ToolkitPage';
import ExamsPage from './pages/ExamsPage';
import StatsPage from './pages/StatsPage';
import SettingsPage from './pages/SettingsPage';

export default function App() {
  const auth = useAuth();
  const { loading, error, clearError } = useApp();

  if (auth.status === 'loading') {
    return <div className="spinner" />;
  }

  if (auth.status === 'anon') {
    return <Login />;
  }

  return (
    <>
      {error ? (
        <div className="banner err" style={{ margin: 12 }}>
          {error}{' '}
          <button className="btn sm ghost" onClick={clearError} style={{ marginLeft: 8 }}>
            Đóng
          </button>
        </div>
      ) : null}
      {loading ? (
        <div className="spinner" />
      ) : (
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/today" replace />} />
            <Route path="/today" element={<Today />} />
            <Route path="/roadmap" element={<Roadmap />} />
            <Route path="/quiz" element={<Quiz />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/toolkit" element={<ToolkitPage />} />
            <Route path="/exams" element={<ExamsPage />} />
            <Route path="/stats" element={<StatsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/today" replace />} />
          </Route>
        </Routes>
      )}
    </>
  );
}
