// @vitest-environment jsdom
import { beforeEach, describe, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import App from './App';

function renderApp() {
  return render(
    <MemoryRouter initialEntries={['/today']}>
      <AuthProvider>
        <AppProvider>
          <App />
        </AppProvider>
      </AuthProvider>
    </MemoryRouter>,
  );
}

beforeEach(() => {
  localStorage.clear();
  cleanup();
});

describe('cổng đăng nhập', () => {
  it('từ chối email lạ và cho vào bằng đúng tqbaoan2k11@gmail.com', async () => {
    renderApp();
    const input = (await screen.findByPlaceholderText('tqbaoan2k11@gmail.com')) as HTMLInputElement;

    fireEvent.change(input, { target: { value: 'nguoila@gmail.com' } });
    fireEvent.click(screen.getByText('Vào học'));
    await screen.findByText(/Email không đúng/);

    fireEvent.change(input, { target: { value: 'tqbaoan2k11@gmail.com' } });
    fireEvent.click(screen.getByText('Vào học'));
    await screen.findByText(/Nhiệm vụ hôm nay/);
    expect(localStorage.getItem('vaio-local-session-v1')).toBe('tqbaoan2k11@gmail.com');
  });
});

describe('ghi nhớ lịch sử học (lỗi "app quên lịch sử")', () => {
  it('tick nhiệm vụ, tải lại trang vẫn giữ nguyên tiến độ và XP', async () => {
    localStorage.setItem('vaio-local-session-v1', 'tqbaoan2k11@gmail.com');
    const { unmount } = renderApp();

    const boxes = await screen.findAllByRole('checkbox');
    fireEvent.click(boxes[0]);

    await waitFor(() => {
      const raw = localStorage.getItem('vaio-roadmap-v1');
      expect(raw).toBeTruthy();
      const parsed = JSON.parse(raw as string) as { snapshot: { tasks: Record<string, number[]>; xpEvents: Record<string, unknown> } };
      const keys = Object.keys(parsed.snapshot.tasks);
      expect(keys.length).toBe(1);
      expect(parsed.snapshot.tasks[keys[0]]).toEqual([0]);
      expect(Object.keys(parsed.snapshot.xpEvents).length).toBe(1);
    });

    unmount();
    renderApp();

    await waitFor(() => {
      const boxes2 = screen.getAllByRole('checkbox') as HTMLInputElement[];
      expect(boxes2[0].checked).toBe(true);
    });
  });

  it('bấm tick rồi bỏ tick: XP trở về 0, không còn điểm ảo', async () => {
    localStorage.setItem('vaio-local-session-v1', 'tqbaoan2k11@gmail.com');
    renderApp();

    const boxes = await screen.findAllByRole('checkbox');
    fireEvent.click(boxes[0]);
    await waitFor(() => {
      const parsed = JSON.parse(localStorage.getItem('vaio-roadmap-v1') as string);
      expect(Object.keys(parsed.snapshot.xpEvents).length).toBe(1);
    });

    fireEvent.click(screen.getAllByRole('checkbox')[0]);
    await waitFor(() => {
      const parsed = JSON.parse(localStorage.getItem('vaio-roadmap-v1') as string);
      expect(Object.keys(parsed.snapshot.xpEvents).length).toBe(0);
      expect(Object.keys(parsed.snapshot.activities ?? {}).length).toBe(0);
    });
  });
});
