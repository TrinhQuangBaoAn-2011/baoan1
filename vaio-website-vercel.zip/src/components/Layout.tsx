import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { Sticker } from './ui';
import { useTheme } from '../lib/theme';

const LINKS = [
  { to: '/today', label: 'Hôm nay', icon: '🏠' },
  { to: '/roadmap', label: 'Lộ trình', icon: '🗺️' },
  { to: '/quiz', label: 'Quiz', icon: '🧠' },
  { to: '/calendar', label: 'Chuỗi ngày', icon: '🔥' },
  { to: '/library', label: 'Thư viện', icon: '📚' },
  { to: '/toolkit', label: 'Toolkit', icon: '🧰' },
  { to: '/exams', label: 'Đề thi', icon: '🏁' },
  { to: '/stats', label: 'Thống kê', icon: '📊' },
  { to: '/settings', label: 'Cài đặt', icon: '⚙️' },
];

const PRIMARY = LINKS.slice(0, 5);
const MORE = LINKS.slice(5);

export default function Layout() {
  const { xp, streak, level } = useApp();
  const auth = useAuth();
  const { theme, toggle } = useTheme();
  const location = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    setMoreOpen(false);
  }, [location.pathname]);

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <NavLink to="/today" className="logo" aria-label="Về trang Hôm nay">
            <Sticker emoji="🎯" size="sm" />
            <span className="logo-text">
              Roadmap <span>VAIO · IOAI</span>
            </span>
          </NavLink>
          <div className="topbar-stats">
            <span className="stat-chip" title={`Cấp ${level.level + 1}: ${level.name}`}>
              <Sticker emoji="⚡" size="xs" /> <b>{xp.toLocaleString('vi-VN')}</b> XP
            </span>
            <span className="stat-chip" title="Chuỗi ngày học liên tiếp">
              <Sticker emoji="🔥" size="xs" /> <b>{streak.current}</b> ngày
            </span>
            <span className="stat-chip hide-sm" title={`Cấp ${level.level + 1}`}>
              <Sticker emoji="🏅" size="xs" /> {Math.round(level.progress * 100)}%
            </span>
            <button
              className="theme-btn"
              onClick={toggle}
              aria-label={theme === 'dark' ? 'Chuyển sang giao diện sáng' : 'Chuyển sang giao diện tối'}
              title={theme === 'dark' ? 'Giao diện sáng' : 'Giao diện tối'}
            >
              {theme === 'dark' ? '☀️' : '🌙'}
            </button>
          </div>
        </div>
        <nav className="nav" aria-label="Điều hướng chính">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) => (isActive ? 'active' : '')}>
              <span aria-hidden="true">{l.icon}</span> {l.label}
            </NavLink>
          ))}
        </nav>
      </header>

      <div className="app-shell">
        {auth.mode === 'local' ? (
          <div className="banner warn">
            Đang chạy <b>chế độ LOCAL</b>: tiến độ lưu trong trình duyệt này. Muốn đồng bộ điện thoại + máy tính và đăng nhập
            Google thật, xem hướng dẫn ở <NavLink to="/settings">Cài đặt</NavLink>.
          </div>
        ) : null}
        <main>
          <Outlet />
        </main>
      </div>

      <nav className="bottom-nav" aria-label="Điều hướng di động">
        {PRIMARY.map((l) => (
          <NavLink key={l.to} to={l.to} className={({ isActive }) => `bottom-link ${isActive ? 'active' : ''}`}>
            <span className="bottom-icon" aria-hidden="true">
              {l.icon}
            </span>
            <span>{l.label}</span>
          </NavLink>
        ))}
        <div className="bottom-more">
          <button
            className={`bottom-link ${MORE.some((l) => l.to === location.pathname) ? 'active' : ''}`}
            onClick={() => setMoreOpen((o) => !o)}
            aria-expanded={moreOpen}
            aria-label="Mở thêm mục"
          >
            <span className="bottom-icon" aria-hidden="true">
              ☰
            </span>
            <span>Khác</span>
          </button>
          {moreOpen ? (
            <div className="more-panel">
              {MORE.map((l) => (
                <NavLink key={l.to} to={l.to} className={({ isActive }) => (isActive ? 'active' : '')}>
                  <span aria-hidden="true">{l.icon}</span> {l.label}
                </NavLink>
              ))}
            </div>
          ) : null}
        </div>
      </nav>
    </>
  );
}
