export type TaskType =
  | 'read'
  | 'code'
  | 'quiz'
  | 'note'
  | 'lab'
  | 'review'
  | 'mock'
  | 'rest'
  | 'exam';

export interface Task {
  type: TaskType;
  label: string;
  xp: number;
  minutes: number;
}

export type DayKind = 'lesson' | 'lab' | 'checkpoint' | 'mock' | 'rest' | 'exam';

export interface DayPlan {
  id: string;
  index: number; // 1..364
  date: string; // YYYY-MM-DD
  week: number; // 1..52
  phase: string;
  theme: string;
  title: string;
  kind: DayKind;
  tags: string[];
  tasks: Task[];
}

export type QuestionType = 'mcq' | 'multi' | 'fill';

export interface Question {
  id: string;
  tags: string[];
  type: QuestionType;
  q: string;
  options?: string[];
  /** mcq: number (index) · multi: number[] · fill: string[] (đáp án chấp nhận) */
  a: number | number[] | string[];
  why: string;
}

export interface QuizAnswer {
  qid: string;
  correct: boolean;
  given: string[];
}

export type QuizKind = 'daily' | 'fast' | 'review' | 'mock' | 'practice';

export interface QuizSession {
  id: string;
  dayId: string;
  kind: QuizKind;
  startedAt: string;
  finishedAt: string;
  score: number;
  total: number;
  tags: string[];
  details: QuizAnswer[];
}

export interface ReviewItem {
  due: string;
  intervalIdx: number;
  wrong: number;
  last: 'right' | 'wrong';
}

export type RefStatus = 'todo' | 'doing' | 'done';

export interface RefProgress {
  status: RefStatus;
  note: string;
  updatedAt: string;
}

export interface Activity {
  date: string;
  xp: number;
  minutes: number;
  tasks: number;
  quizzes: number;
}

export interface XpEvent {
  key: string;
  amount: number;
  date: string;
  source: string;
}

export interface MockExam {
  id: string;
  title: string;
  takenAt: string;
  durationMin: number;
  score: number;
  total: number;
  notes: string;
}

export interface Profile {
  email: string;
  name: string;
  startDate: string;
  examDates: { vaio?: string; voai?: string; ioai?: string; iaio?: string };
  dailyGoalMin: number;
}

export interface Snapshot {
  profile: Profile;
  /** dayId -> danh sách index task đã hoàn thành */
  tasks: Record<string, number[]>;
  /** eventKey duy nhất -> sự kiện XP (chống cộng trùng) */
  xpEvents: Record<string, XpEvent>;
  quizzes: QuizSession[];
  review: Record<string, ReviewItem>;
  refs: Record<string, RefProgress>;
  activities: Record<string, Activity>;
  freezes: string[];
  mocks: MockExam[];
}

export const ALLOWED_EMAIL = 'tqbaoan2k11@gmail.com';

export const DEFAULT_START_DATE = '2026-10-20';
