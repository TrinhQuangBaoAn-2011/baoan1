import type { Snapshot } from '../types';
import type { Ops } from '../mutations';
import { defaultSnapshot } from '../mutations';
import type { Store } from './types';

const KEY = 'vaio-roadmap-v1';

interface Saved {
  version: 1;
  email: string;
  savedAt: string;
  snapshot: Snapshot;
}

function validSnapshot(x: unknown): x is Snapshot {
  if (!x || typeof x !== 'object') return false;
  const s = x as Snapshot;
  return Boolean(s.profile && typeof s.profile === 'object' && s.tasks && s.xpEvents && Array.isArray(s.quizzes));
}

/**
 * Chế độ LOCAL: lưu toàn bộ tiến độ trong localStorage của trình duyệt.
 * Dữ liệu không mất khi tải lại trang; đổi máy/đổi trình duyệt thì không đồng bộ.
 */
export function createLocalStore(email: string): Store {
  function read(): Snapshot {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return defaultSnapshot(email);
      const parsed = JSON.parse(raw) as Saved;
      if (parsed && parsed.version === 1 && validSnapshot(parsed.snapshot)) {
        return { ...defaultSnapshot(email), ...parsed.snapshot, profile: { ...defaultSnapshot(email).profile, ...parsed.snapshot.profile } };
      }
      return defaultSnapshot(email);
    } catch {
      return defaultSnapshot(email);
    }
  }

  function write(snap: Snapshot) {
    const payload: Saved = { version: 1, email, savedAt: new Date().toISOString(), snapshot: snap };
    localStorage.setItem(KEY, JSON.stringify(payload));
  }

  return {
    mode: 'local',
    async load() {
      return read();
    },
    async persist(snap: Snapshot, _ops: Ops) {
      void _ops;
      write(snap);
    },
    async reset() {
      const s = defaultSnapshot(email);
      write(s);
      return s;
    },
    async importSnapshot(snap: Snapshot) {
      if (!validSnapshot(snap)) throw new Error('File sao lưu không hợp lệ');
      const merged: Snapshot = { ...defaultSnapshot(email), ...snap, profile: { ...defaultSnapshot(email).profile, ...snap.profile, email } };
      write(merged);
      return merged;
    },
  };
}
