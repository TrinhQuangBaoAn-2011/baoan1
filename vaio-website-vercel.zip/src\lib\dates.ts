/** Tiện ích ngày tháng — tất cả dùng giờ LOCAL, định dạng YYYY-MM-DD. */

export function toISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function todayISO(): string {
  return toISO(new Date());
}

export function parseISO(iso: string): Date {
  const [y, m, d] = iso.split('-').map((x) => parseInt(x, 10));
  return new Date(y, (m || 1) - 1, d || 1);
}

export function addDays(iso: string, n: number): string {
  const d = parseISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
}

/** Số ngày từ a đến b (b - a). */
export function diffDays(a: string, b: string): number {
  const ms = parseISO(b).getTime() - parseISO(a).getTime();
  return Math.round(ms / 86400000);
}

export function formatVN(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

const WEEKDAYS = ['Chủ nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];

export function weekdayVN(iso: string): string {
  return WEEKDAYS[parseISO(iso).getDay()];
}

export function weekdayShort(iso: string): string {
  return ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'][parseISO(iso).getDay()];
}

export function daysInMonth(y: number, m: number): number {
  return new Date(y, m, 0).getDate();
}

export function isoOfMonthDay(y: number, m: number, day: number): string {
  return toISO(new Date(y, m - 1, day));
}

export function isoRange(start: string, end: string): string[] {
  const out: string[] = [];
  let cur = start;
  let guard = 0;
  while (cur <= end && guard < 4000) {
    out.push(cur);
    cur = addDays(cur, 1);
    guard++;
  }
  return out;
}

export function isWeekend(iso: string): boolean {
  const g = parseISO(iso).getDay();
  return g === 0 || g === 6;
}

/** Đầu tuần (thứ Hai) của ngày cho trước. */
export function mondayOf(iso: string): string {
  const d = parseISO(iso);
  const g = d.getDay();
  const delta = g === 0 ? -6 : 1 - g;
  d.setDate(d.getDate() + delta);
  return toISO(d);
}

export function currentMonth(): { y: number; m: number } {
  const d = new Date();
  return { y: d.getFullYear(), m: d.getMonth() + 1 };
}
